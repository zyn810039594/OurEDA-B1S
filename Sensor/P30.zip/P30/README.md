# 声呐

连接到控制板的stm32上

使用串口UART5

这里引用了一个官方的上位机源码ping-viewer

使用

```shell
git submodule init
git submodule pull
```

拉取submodule

[参考资料](https://searobotix.com/p30-sonar/)